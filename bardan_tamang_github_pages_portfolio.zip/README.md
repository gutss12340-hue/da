# Bardan Tamang — Student Portfolio

A static, Elden Ring-inspired medieval-fantasy student portfolio designed for GitHub Pages.

## Files

- `index.html` — portfolio content
- `style.css` — responsive styling and animations
- `script.js` — mobile menu, reveal animations, and ambient embers
- `assets/` — reserved for future images

## GitHub Pages

1. Create a GitHub repository, for example `bardan-portfolio`.
2. Upload `index.html`, `style.css`, `script.js`, and the `assets` folder.
3. Commit the files to the repository.
4. In GitHub, open **Settings → Pages**.
5. Under the Pages source/build settings, select deployment from the repository's main branch and the root folder.
6. Save. GitHub will provide the published Pages address.

## Before publishing

Replace `YOUR_EMAIL@example.com` in `index.html` with your real email address.

When you have projects, add project cards to the Journey section with GitHub/demo links.

The visual style is original dark medieval fantasy inspiration and does not use copied Elden Ring artwork, logos, or game assets.
