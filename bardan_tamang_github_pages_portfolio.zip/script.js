const nav = document.querySelector(".nav");
const toggle = document.querySelector(".menu-toggle");

toggle.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  toggle.setAttribute("aria-expanded", open);
});

document.querySelectorAll(".nav a").forEach(link => {
  link.addEventListener("click", () => {
    nav.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
  });
});

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll(".reveal").forEach(el => observer.observe(el));

const embers = document.querySelector(".embers");
for (let i = 0; i < 28; i++) {
  const ember = document.createElement("i");
  ember.style.left = Math.random() * 100 + "%";
  ember.style.animationDelay = (Math.random() * 8) + "s";
  ember.style.animationDuration = (6 + Math.random() * 8) + "s";
  ember.style.transform = `scale(${0.5 + Math.random() * 1.4})`;
  embers.appendChild(ember);
}

document.getElementById("year").textContent = new Date().getFullYear();
